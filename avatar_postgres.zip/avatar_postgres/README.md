# Avatar — Full project (PostgreSQL + Node.js + OpenAI + Stripe)

This project is prepared to deploy on a platform that supports Node.js apps and PostgreSQL (e.g. Render, Railway).
It includes a small Express backend, PostgreSQL initialization, OpenAI integration endpoint and Stripe payment intent example.

## Files
- `server.js` — main server (Express)
- `db.js` — Postgres pool and `initDB()` (creates tables if not exist)
- `public/` — frontend (index.html, styles.css)
- `.env.example` — environment variables to set

## Environment variables (copy these into Render/Service provider -> Environment)
- `DATABASE_URL` — Postgres connection string (example: postgres://user:pass@host:5432/dbname)
- `JWT_SECRET` — strong JWT secret
- `OPENAI_API_KEY` — OpenAI API key
- `STRIPE_SECRET_KEY` — Stripe Secret Key
- `EMAIL_SERVICE` — optional (gmail)
- `EMAIL_USER` — email used to send OTPs
- `EMAIL_PASS` — password or app-password for SMTP
- `EMAIL_FROM` — optional "Avatar <you@domain.com>"
- `GOOGLE_MAPS_API_KEY` — optional, used by frontend for maps

## Quick local run (optional)
1. Create `.env` from `.env.example` and fill values.
2. `npm install`
3. `npm start`
4. Open http://localhost:5000

## Deploy on Render (recommended)
1. Create a new **Web Service** on Render and connect your GitHub repo which contains this project.
2. Build command: `npm install`
3. Start command: `npm start`
4. Add environment variables (DATABASE_URL, JWT_SECRET, OPENAI_API_KEY, STRIPE_SECRET_KEY, EMAIL_USER, EMAIL_PASS, ...)
5. If you don't have a PostgreSQL database yet, create a **Postgres** service on Render, set it up and copy its `DATABASE_URL` to the Web Service env.
6. Deploy. Render will run `server.js` and your app will be available at the service URL.

## Notes
- Do not commit real secrets to public Git repos.
- For production email sending, use SendGrid/Mailgun for better reliability.
- For Stripe webhooks, set up webhook endpoint to securely confirm payments.
