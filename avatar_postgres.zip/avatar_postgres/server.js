/**
 * server.js - Avatar (Postgres) monolith
 * - Expects environment variables (see .env.example)
 * - Start: node server.js
 */
const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const Stripe = require('stripe');
const OpenAI = require('openai');
const db = require('./db');

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'change_this';
const stripe = Stripe(process.env.STRIPE_SECRET || '');
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || '' });

// nodemailer transporter (use SendGrid/Mailgun in prod)
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
});

// simple helpers
const signToken = (user) => jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '30d' });
const requireAuth = async (req, res, next) => {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ error: 'Not authorized' });
  const token = h.replace('Bearer ', '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch(e) { return res.status(401).json({ error: 'Invalid token' }); }
};

// --- DB initialization helper (creates tables if not exist) ---
async function initDB(){
  await db.query(`CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY, name TEXT, email TEXT UNIQUE, password_hash TEXT, role TEXT, verified BOOLEAN DEFAULT false, otp TEXT, credits INT DEFAULT 0, created_at TIMESTAMP DEFAULT now()
  );`);
  await db.query(`CREATE TABLE IF NOT EXISTS providers (
    id SERIAL PRIMARY KEY, name TEXT, category TEXT, description TEXT, price INT, contact TEXT, score FLOAT DEFAULT 0, owner_user_id INT REFERENCES users(id), created_at TIMESTAMP DEFAULT now()
  );`);
  await db.query(`CREATE TABLE IF NOT EXISTS reviews (
    id SERIAL PRIMARY KEY, provider_id INT REFERENCES providers(id), user_id INT REFERENCES users(id), stars INT, comment TEXT, created_at TIMESTAMP DEFAULT now()
  );`);
}
initDB().catch(err => console.error('initDB err', err));

// --- AUTH ---
app.post('/api/register', async (req, res)=>{
  try {
    const { name, email, password, role } = req.body;
    if(!email || !password) return res.status(400).json({ error: 'missing' });
    const hashed = await bcrypt.hash(password, 10);
    const otp = Math.floor(100000 + Math.random()*900000).toString();
    const r = await db.query('INSERT INTO users (name,email,password_hash,role,otp) VALUES ($1,$2,$3,$4,$5) RETURNING id,email,name,role', [name,email,hashed,role||'client',otp]);
    // send OTP
    try {
      await transporter.sendMail({ from: process.env.EMAIL_FROM || process.env.EMAIL_USER, to: email, subject: 'Avatar OTP', text: 'رمز التحقق: ' + otp });
    } catch(e) { console.warn('email send failed', e.message || e); }
    res.json({ ok:true, message:'registered_otp_sent', user: r.rows[0] });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

app.post('/api/verify-otp', async (req,res)=>{
  try {
    const { email, otp } = req.body;
    const r = await db.query('SELECT id,otp FROM users WHERE email=$1', [email]);
    if(!r.rows.length) return res.status(400).json({ error: 'no_user' });
    if(r.rows[0].otp !== otp) return res.status(400).json({ error: 'invalid_otp' });
    await db.query('UPDATE users SET verified=true, otp=NULL WHERE id=$1', [r.rows[0].id]);
    const user = await db.query('SELECT id,name,email,role,credits FROM users WHERE id=$1', [r.rows[0].id]);
    const token = signToken({ id: user.rows[0].id, email: user.rows[0].email, role: user.rows[0].role });
    res.json({ ok:true, token, user: user.rows[0] });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

app.post('/api/login', async (req,res)=>{
  try {
    const { email, password } = req.body;
    const r = await db.query('SELECT id,name,email,password_hash,role,credits FROM users WHERE email=$1', [email]);
    if(!r.rows.length) return res.status(400).json({ error: 'no_user' });
    const user = r.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if(!ok) return res.status(400).json({ error: 'bad_credentials' });
    const token = signToken({ id: user.id, email: user.email, role: user.role });
    res.json({ ok:true, token, user: { id: user.id, name: user.name, email: user.email, role: user.role, credits: user.credits } });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

// --- Providers & Reviews ---
app.post('/api/providers', requireAuth, async (req,res)=>{
  try {
    const { name, category, description, price, contact, location } = req.body;
    const r = await db.query('INSERT INTO providers (name,category,description,price,contact,owner_user_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *', [name,category,description,price,contact,req.user.id]);
    res.json({ ok:true, provider: r.rows[0] });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

app.get('/api/providers', async (req,res)=>{
  try {
    const q = req.query.q || '';
    const providers = await db.query("SELECT * FROM providers WHERE name ILIKE $1 OR category ILIKE $1 OR description ILIKE $1 ORDER BY score DESC LIMIT 200", ['%' + q + '%']);
    res.json({ ok:true, providers: providers.rows });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

app.post('/api/providers/:id/review', requireAuth, async (req,res)=>{
  try {
    const { stars, comment } = req.body;
    const providerId = req.params.id;
    await db.query('INSERT INTO reviews (provider_id,user_id,stars,comment) VALUES ($1,$2,$3,$4)', [providerId, req.user.id, stars, comment]);
    // update avg
    const agg = await db.query('SELECT AVG(stars) as avg FROM reviews WHERE provider_id=$1', [providerId]);
    await db.query('UPDATE providers SET score=$1 WHERE id=$2', [agg.rows[0].avg || stars, providerId]);
    res.json({ ok:true });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

// --- Payments (Stripe) ---
app.post('/api/payments/create-intent', requireAuth, async (req,res)=>{
  try {
    const { amount, currency } = req.body;
    if(!amount) return res.status(400).json({ error: 'amount required' });
    const pi = await stripe.paymentIntents.create({ amount: Math.round(amount), currency: currency || 'egp', automatic_payment_methods: { enabled: true } });
    res.json({ ok:true, clientSecret: pi.client_secret, id: pi.id });
  } catch(e){ console.error('stripe err', e.message || e); res.status(500).json({ error: e.message }); }
});

app.post('/api/payments/confirm', requireAuth, async (req,res)=>{
  try {
    const { paymentIntentId, creditsToAdd } = req.body;
    const pi = await stripe.paymentIntents.retrieve(paymentIntentId);
    if(['succeeded','requires_capture','processing'].includes(pi.status)){
      await db.query('UPDATE users SET credits = credits + $1 WHERE id=$2', [creditsToAdd || 10, req.user.id]);
      return res.json({ ok:true });
    }
    return res.status(400).json({ error: 'payment_not_completed', status: pi.status });
  } catch(e){ console.error(e); res.status(500).json({ error: e.message }); }
});

// --- AI assistant endpoint (uses OpenAI responses.create)
app.post('/api/ai/query', async (req,res)=>{
  try {
    const { prompt } = req.body;
    if(!prompt) return res.status(400).json({ error: 'prompt required' });
    // check user credits
    let user = null;
    const auth = req.headers.authorization;
    if(auth){
      try { user = jwt.verify(auth.replace('Bearer ', ''), JWT_SECRET); } catch(e) { user = null; }
    }
    let model = 'gpt-4o-mini';
    let mode = 'free';
    if(user){
      const u = await db.query('SELECT credits FROM users WHERE id=$1', [user.id]);
      if(u.rows[0] && u.rows[0].credits > 0){
        model = 'gpt-4o';
        mode = 'paid';
        await db.query('UPDATE users SET credits = credits - 1 WHERE id=$1', [user.id]);
      }
    }
    const instructions = `You are AvatarAssist. Return JSON only: {"diagnosis": string, "steps":[string], "recommended_category": string, "confidence": number}`;
    const resp = await openai.responses.create({ model, input: instructions + "\nUser: " + prompt, max_tokens: 600 });
    const aiText = resp.output_text || JSON.stringify(resp);
    let aiJson = null;
    try { aiJson = JSON.parse(aiText); } catch(e) { aiJson = null; }
    if(!aiJson) aiJson = { diagnosis: aiText.slice(0,1000), steps: [], recommended_category:'', confidence: 0 };
    // find recommended providers
    let recProviders = [];
    if(aiJson.recommended_category) {
      const rec = await db.query('SELECT * FROM providers WHERE category=$1 ORDER BY score DESC LIMIT 6', [aiJson.recommended_category]);
      recProviders = rec.rows;
    } else {
      const q = prompt.split(/\s+/).slice(0,6).join(' ');
      const rec = await db.query("SELECT * FROM providers WHERE name ILIKE $1 OR description ILIKE $1 OR category ILIKE $1 ORDER BY score DESC LIMIT 6", ['%' + q + '%']);
      recProviders = rec.rows;
    }
    res.json({ ok:true, mode, aiJson, recProviders });
  } catch(e){ console.error('AI error', e.message || e); res.status(500).json({ error: e.message }); }
});

// Serve frontend
app.get('/', (req,res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// Start
app.listen(PORT, () => console.log(`🚀 Avatar (Postgres) running on port ${PORT}`));
