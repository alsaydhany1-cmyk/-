/**
 * db.js - PostgreSQL helper using pg Pool
 * Expects DATABASE_URL in env (Postgres connection string)
 */
const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // for self-signed / some hosts you may need:
  // ssl: { rejectUnauthorized: false }
});
module.exports = {
  query: (text, params) => pool.query(text, params),
  pool
};
